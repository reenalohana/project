﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Text;
using System.Configuration;

public partial class Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (this.IsPostBack)
        {
            lblWelcome.Text = "Welcome " + this.Request.Form["txtName"] + "!";

            //Response.Write("<div class=content>Current Server Time is " + DateTime.Now.ToLongTimeString() + "<br></div>");
            lblServerTime.Text = "<div class=content>Current Server Time is " + DateTime.Now.ToLongTimeString() + "<br></div>";

            string strWelcome = "";

            if (DateTime.Now.Hour >= 0 && DateTime.Now.Hour <= 11)
            {
                strWelcome = "Good morning";
            }
            else if (DateTime.Now.Hour >= 12 && DateTime.Now.Hour <= 17)
            {
                strWelcome = "Good afternoon";
            }
            else if (DateTime.Now.Hour >= 18 && DateTime.Now.Hour <= 23)
            {
                strWelcome = "Good evening";
            }
            else
            {
                strWelcome = "Time error";
            }

            //Response.Write("<div class=content>" + strWelcome + "<br/></div>");
            lblGreeting.Text = "<div class=content>" + strWelcome + "<br/></div>";

            //Added for Week 5 Session 1
            SaveRegistration();
        }

    }

    private void SaveRegistration()
    {
        OleDbConnectionStringBuilder sb = new OleDbConnectionStringBuilder();
        //sb.Provider = "Microsoft.ACE.OLEDB.12.0";
        ////sb.DataSource = Server.MapPath("/wad14s1/uploads/database1.accdb");
        //sb.DataSource = Server.MapPath("~/../uploads/database1.accdb");

        //Use Web.config file in Week 8 Seesion 2
        sb.Provider = ConfigurationManager.AppSettings["Provider"];
        sb.DataSource = Server.MapPath(ConfigurationManager.AppSettings["DatabasePath"]);

        // The following describes connection parameters (connection string) to SQL Server
        // Initial Catalog, Login and Password you need specify
        //sb.Provider = "SQLOLEDB";
        //sb.DataSource = "hyperdisc.unitec.ac.nz";
        //sb.Add("Initial Catalog", "wad14s1mysql1");
        //sb.Add("User ID", "wad14s1");
        //sb.Add("Password", "********");

        OleDbConnection myConnection = new OleDbConnection(sb.ConnectionString);

        //Added try/catch block in Week 8 Session 1, 13/4/2014
        try
        {
            //Put original method body content here except variable declaration and close connection
            string queryString = "";
            OleDbCommand myCmd = new OleDbCommand(queryString, myConnection);

            myConnection.Open();

            StringBuilder queryStringBuilder = new StringBuilder("Insert into Employees([Last Name], [First Name], [Job Title], [Company], [Home Phone], [Address])");

            queryStringBuilder.Append("values ('");
            queryStringBuilder.Append(Request.Form["txtName"]);
            queryStringBuilder.Append("','");
            queryStringBuilder.Append(Request.Form["txtEMail"]);
            queryStringBuilder.Append("','");
            queryStringBuilder.Append(Request.Form["chkPaper"]);
            queryStringBuilder.Append("','");
            queryStringBuilder.Append(Request.Form["rdoAccommodation"]);
            queryStringBuilder.Append("','");
            queryStringBuilder.Append(Request.Form["txtPhone"]);
            queryStringBuilder.Append("',");
            queryStringBuilder.Append(Request.Form["txtTotal"]);
            queryStringBuilder.Append(")");

            queryString = queryStringBuilder.ToString();
            myCmd.CommandText = queryString;

            myCmd.ExecuteNonQuery();

            //Create another command object
            OleDbCommand anotherCmd = new OleDbCommand("SELECT @@IDENTITY", myConnection);
            int numId = Convert.ToInt32(anotherCmd.ExecuteScalar());

            lblDataId.Text = "<h3>Your registration number is <big>" + numId.ToString() + "</big></h3>";

        //myConnection.Close();
        }
        catch (OleDbException exOleDb)
        {
            Session["ExceptionObject"] = exOleDb;
            Server.Transfer("DisplayErrors.aspx?from=Catch OleDb");
        }
        catch (Exception exGeneral)
        {
            Session["ExceptionObject"] = exGeneral;
            Server.Transfer("DisplayErrors.aspx?from=Catch General");
        }
        finally
        {
            if (myConnection != null && myConnection.State == ConnectionState.Open)
            {
                myConnection.Close();
            }
        }

    }

    //Added for Week 8 Session 1, XL, 13/4/2014
    protected override void OnError(EventArgs e)
    {
        Exception ex = Server.GetLastError();
        Session["ExceptionObject"] = ex;
        //Server.ClearError();
        //Server.Transfer("DisplayErrors.aspx?from=RegistrationPage");
    }

}